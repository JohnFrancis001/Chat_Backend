const registerChatHandler = (io, socket) => { // the new chat initializer and handler 
    socket.on("join_room", (roomId) => { // the id to be connected with the previous chats
        const conversationId = roomId; // 

        socket.join(roomId);
    });

    socket.on("send_message", ({ roomId, message }) => {
        io.to(roomId).emit("receive_message",{
            message
        })
    })
}

module.exports = registerChatHandler;
