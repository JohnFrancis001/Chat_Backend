const express = require('express');
const app = express();
const db = require('./db');
const user = require('./routes/user')
const cookieParser = require('cookie-parser');

app.use(express.json());
app.use(cookieParser());

app.use('/user', user);

app.listen(3000, () => {
    console.log("Server running on port: 3000");
})
